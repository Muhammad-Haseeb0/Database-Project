
DROP DATABASE IF EXISTS nams;

CREATE DATABASE IF NOT EXISTS nams;
DELETE DATABASE db;
USE nams;


-- TABLE 1: AGENCY
-- Government Body
-- No foreign keys — must be created first.
CREATE TABLE AGENCY (
    Agency_ID       INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Name            VARCHAR(150)    NOT NULL,
    Location        VARCHAR(200)    NOT NULL,
    Contact         VARCHAR(120)    NOT NULL,
    Evaluation_Date DATE            NOT NULL
);


-- TABLE 2: BUYER

CREATE TABLE BUYER (
    Buyer_ID    INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    First_Name  VARCHAR(80)     NOT NULL,
    Last_Name   VARCHAR(80)     NOT NULL,
    Location     VARCHAR(250)    NOT NULL,
    Contact     VARCHAR(20)     NOT NULL
);


-- TABLE 3: RESOURCE_TYPE
--Table for resource categories
CREATE TABLE RESOURCE_TYPE (
    Type_ID     INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Name        VARCHAR(80)     NOT NULL UNIQUE
);


-- TABLE 4: RESOURCES
-- Big catalog of all agricultural resources
CREATE TABLE RESOURCES (
    Resource_ID     INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Description     VARCHAR(255)    NOT NULL
);

-- TABLE 5: CROPS
-- Big catalog of all crops
CREATE TABLE CROPS (
    Crop_ID     INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Name        VARCHAR(100)    NOT NULL UNIQUE,
    Season      VARCHAR(30)     NOT NULL CHECK (Season IN ('Kharif', 'Rabi', 'Year-round'))
);

-- TABLE 6: WATER_SUPPLY
-- National registry of water sources
CREATE TABLE WATER_SUPPLY (
    Source_ID   INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Name        VARCHAR(80)     NOT NULL UNIQUE,
    Type        VARCHAR(80)     NOT NULL CHECK (Type IN ('Canal', 'Well', 'River', 'Dam'))
);


-- TABLE 8: OWNER
CREATE TABLE OWNER (
    Owner_ID    INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    First_Name  VARCHAR(80)     NOT NULL,
    Last_Name   VARCHAR(80)     NOT NULL,
    Location     VARCHAR(250)    NOT NULL,
    Contact     VARCHAR(20)     NOT NULL,
    Balance     DECIMAL(15,2)   NOT NULL DEFAULT 0.00,
    Taxable     BOOLEAN         NOT NULL    DEFAULT TRUE

);

-- TABLE 7: FARM
-- Depends on: AGENCY
-- Central entity of the entire system
CREATE TABLE FARM (
    Farm_ID     INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Agency_ID   INT             NOT NULL,
    Owner_ID   INT             NOT NULL,
    Name        VARCHAR(150)    NOT NULL,
    Location    VARCHAR(250)    NOT NULL,

    FOREIGN KEY (Agency_ID) REFERENCES AGENCY (Agency_ID),
    FOREIGN KEY (Owner_ID) REFERENCES OWNER (Owner_ID)
);




-- TABLE 9: LAND
-- Land characteristics for a farm.
-- Depends on: FARM
CREATE TABLE LAND (
    Land_ID     INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Farm_ID     INT             NOT NULL,
    Soil        VARCHAR(100)    NOT NULL,
    Area        DECIMAL(10,2)   NOT NULL, 

    FOREIGN KEY (Farm_ID) REFERENCES FARM(Farm_ID)
);



-- TABLE 10: SALES
-- Records crop sale transactions.
-- Depends on: FARM, BUYER, CROPS
CREATE TABLE SALES (
    Sale_ID     INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Buyer_ID    INT             NOT NULL,
    Farm_ID     INT             NOT NULL,
    Crop_ID     INT             NOT NULL,
    Units       INT             NOT NULL CHECK (Units > 0),
    Price       DOUBLE          NOT NULL CHECK (Price >= 0),
    Tax         DOUBLE          NOT NULL DEFAULT 0,
    Date        DATE            NOT NULL,

    FOREIGN KEY (Buyer_ID) REFERENCES BUYER(Buyer_ID),
    FOREIGN KEY (Farm_ID)  REFERENCES FARM(Farm_ID),
    FOREIGN KEY (Crop_ID)  REFERENCES CROPS(Crop_ID)
);
---- This would be done during CREATE TABLE
--Tax DECIMAL(10,2) AS (CASE WHEN Units > 100 THEN (Units * Price * 0.18) ELSE (Units * Price * 0.10) END)



-- TABLE 11: PURCHASES
-- Records resource acquisition by farms.
-- Depends on: FARM, RESOURCES
CREATE TABLE PURCHASES (
    Purchases_ID  INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Farm_ID       INT           NOT NULL,
    Resource_ID   INT           NOT NULL,
    Units         INT           NOT NULL CHECK (Units > 0),
    Price         DOUBLE        NOT NULL CHECK (Price >= 0),
    Tax           DOUBLE        NOT NULL DEFAULT 0,
    Date          DATE          NOT NULL,

    
    FOREIGN KEY (Farm_ID)     REFERENCES FARM(Farm_ID),
    FOREIGN KEY (Resource_ID) REFERENCES RESOURCES(Resource_ID)

  
);
  

-- TABLE 12: FARM_CROP
-- Junction table linking Farms to the Crops they grow.
-- Depends on: FARM, CROPS
CREATE TABLE FARM_CROP (
    Farm_ID     INT             NOT NULL,
    Crop_ID     INT             NOT NULL,

    
    FOREIGN KEY (Farm_ID) REFERENCES FARM(Farm_ID),
    FOREIGN KEY (Crop_ID) REFERENCES CROPS(Crop_ID)

   
);


-- TABLE 13: FARM_WATER
-- Junction table linking Farms_Lands to their Water Sources.
-- Depends on: Land, WATER_SUPPLY
CREATE TABLE FARM_WATER (
    Land_ID     INT             NOT NULL,
    Source_ID   INT             NOT NULL,

    
    FOREIGN KEY (Land_ID)   REFERENCES LAND(Land_ID),
    FOREIGN KEY (Source_ID) REFERENCES WATER_SUPPLY(Source_ID)

   
);
 

-- TABLE 14: FARM_RESOURCE_TYPE
-- Links Farms to specific Resource Categories (e.g., Fertilizer, Seed).
-- Depends on: FARM, RESOURCE_TYPE

CREATE TABLE FARM_RESOURCE_TYPE (
    Farm_ID     INT             NOT NULL,
    Type_ID     INT             NOT NULL,

    
    FOREIGN KEY (Farm_ID) REFERENCES FARM(Farm_ID),
    FOREIGN KEY (Type_ID) REFERENCES RESOURCE_TYPE(Type_ID)

    
);


-- TABLE 15: FARM_RES_TYPE_RESOURCE
-- Triple-junction linking Farm, Resource Type, and Resource.
-- Depends on: FARM, RESOURCE_TYPE, RESOURCES
CREATE TABLE FARM_RES_TYPE_RESOURCE (
    Farm_ID      INT            NOT NULL,
    Type_ID      INT            NOT NULL,
    Resource_ID  INT            NOT NULL,

    FOREIGN KEY (Farm_ID)     REFERENCES FARM(Farm_ID),
    FOREIGN KEY (Type_ID)     REFERENCES RESOURCE_TYPE(Type_ID),
    FOREIGN KEY (Resource_ID) REFERENCES RESOURCES(Resource_ID)

    
);



SHOW TABLES;

SHOW DATABASES;




WITH Farm_Revenue AS ( 
   SELECT 
       F.Farm_ID, 
       F.Agency_ID, 
       SUM(S.Price) AS Farm_Total 
   FROM FARM F 
   JOIN SALES S USING (Farm_ID) 
   GROUP BY F.Farm_ID, F.Agency_ID 
), 
Agency_Revenue AS ( 
   SELECT 
       Agency_ID, 
       COUNT(Farm_ID)   AS Total_Farms, 
       SUM(Farm_Total)  AS Agency_Total, 
       AVG(Farm_Total)  AS Avg_Farm_Revenue 
   FROM Farm_Revenue 
   GROUP BY Agency_ID 
), 
System_Avg AS ( 
   SELECT AVG(Farm_Total) AS System_Average 
   FROM Farm_Revenue 
) 
SELECT 
   A.Name                 AS Agency_Name, 
   A.Location, 
   AR.Total_Farms, 
   AR.Agency_Total, 
   AR.Avg_Farm_Revenue, 
   SA.System_Average 
FROM AGENCY A 
JOIN Agency_Revenue AR  USING (Agency_ID) 
JOIN System_Avg SA      ON AR.Avg_Farm_Revenue < SA.System_Average 
ORDER BY AR.Avg_Farm_Revenue ASC; 



WITH Season_Stats AS ( 
   SELECT 
       C.Season, 
       COUNT(DISTINCT S.Farm_ID)  AS Participating_Farms, 
       COUNT(*)                   AS Total_Transactions, 
       SUM(S.Price)               AS Total_Revenue, 
       AVG(S.Price)               AS Avg_Sale_Price 
   FROM CROPS C 
   JOIN SALES S USING (Crop_ID) 
   GROUP BY C.Season 
) 
SELECT 
   Season, 
   Participating_Farms, 
   Total_Transactions, 
Total_Revenue, 
Avg_Sale_Price 
FROM Season_Stats 
ORDER BY Total_Revenue ASC; 




SELECT
F.Location, 
F.Name                 
AS Farm_Name, 
COUNT(DISTINCT C.Season)       
AS Season_Count, 
COUNT(DISTINCT FC.Crop_ID)     AS Total_Crops 
FROM FARM F 
JOIN FARM_CROP FC  USING (Farm_ID) 
JOIN CROPS C       USING (Crop_ID) 
GROUP BY F.Farm_ID, F.Name, F.Location 
HAVING COUNT(DISTINCT C.Season) > 1 
AND COUNT(DISTINCT FC.Crop_ID) > 2 
ORDER BY Season_Count ASC, Total_Crops ASC; 




WITH Resource_Spending AS ( 
   SELECT 
       RT.Name                              AS Resource_Type, 
       COUNT(DISTINCT P.Farm_ID)            AS Farms_Using, 
       COUNT(*)                             AS Total_Purchases, 
       SUM(P.Price)                         AS Total_Spent, 
       AVG(P.Price)                         AS Avg_Spend_Per_Purchase, 
       SUM(P.Price) / COUNT(DISTINCT P.Farm_ID) AS Spend_Per_Farm 
   FROM RESOURCE_TYPE RT 
   JOIN FARM_RES_TYPE_RESOURCE FRTR  USING (Type_ID) 
   JOIN PURCHASES P                  USING (Farm_ID) 
   GROUP BY RT.Type_ID, RT.Name 
) 
SELECT 
Resource_Type, 
Farms_Using, 
Total_Purchases, 
Total_Spent, 
Avg_Spend_Per_Purchase, 
Spend_Per_Farm 
FROM Resource_Spending 
ORDER BY Total_Spent ASC;





WITH Sales_Calc AS (
    SELECT Farm_ID, SUM(Price) as Total_Sales 
    FROM SALES GROUP BY Farm_ID
),

Purchases_Calc AS (
    SELECT Farm_ID, SUM(Price) as Total_Purchases 
    FROM PURCHASES GROUP BY Farm_ID
)
SELECT 
    O.First_Name, 
    O.Last_Name, 
    F.Name AS Farm_Name,
    S.Total_Sales,
    P.Total_Purchases,
    (P.Total_Purchases - S.Total_Sales) AS Net_Loss
FROM OWNER O
JOIN FARM F ON O.Owner_ID = F.Owner_ID
JOIN Sales_Calc S ON F.Farm_ID = S.Farm_ID
JOIN Purchases_Calc P ON F.Farm_ID = P.Farm_ID
WHERE O.Taxable = TRUE
AND P.Total_Purchases > S.Total_Sales; 















-- USE n;

-- -

-- START TRANSACTION;

-- SELECT * 
-- FROM LAND 
-- WHERE Land_ID = 1;

-- SELECT *
-- FROM OWNER
-- WHERE owner_id = 8;

-- UPDATE OWNER 
-- SET Balance = Balance - 150000.00 
-- WHERE Owner_ID = 8 ;

-- SELECT *
-- FROM OWNER
-- WHERE owner_id = 1


-- UPDATE OWNER 
-- SET Balance = Balance + 150000.00 
-- WHERE Owner_ID = 1;



-- UPDATE LAND 
-- SET Farm_ID = 8 
-- WHERE Land_ID = 1;


-- COMMIT;
-- SELECT *
-- FROM OWNER
-- WHERE owner_id IN(1,8);

-- SELECT * 
-- FROM LAND 
-- WHERE Land_ID = 1;





-- START TRANSACTION;

-- INSERT INTO PURCHASES (Farm_ID, Resource_ID, Units, Price, Tax, Date) 
-- VALUES (4, 1, 1, 350000.00, 18.00, '2026-04-27');


-- SELECT balance
-- FROM OWNER
-- WHERE owner_id = 4;

-- UPDATE OWNER 
-- SET Balance = Balance - 350000.00 
-- WHERE Owner_ID = 4;


-- SELECT balance
-- FROM OWNER
-- WHERE owner_id = 4;


-- ROLLBACK;



-- =============================================================
-- TASK 2e: ROLE-BASED ACCESS CONTROL (RBAC)
-- =============================================================
USE nams;

-- 1. Create Roles
-- -------------------------------------------------------------
CREATE ROLE 'Admin_Role';
CREATE ROLE 'Staff_Role';
CREATE ROLE 'Analyst_Role';


GRANT ALL PRIVILEGES ON nams.* TO 'Admin_Role';


GRANT SELECT, INSERT, UPDATE ON nams.FARM TO 'Staff_Role';
GRANT SELECT, INSERT, UPDATE ON nams.FARM_CROP TO 'Staff_Role';
GRANT SELECT, INSERT, UPDATE ON nams.SALES TO 'Staff_Role';
GRANT SELECT, INSERT, UPDATE ON nams.PURCHASES TO 'Staff_Role';


GRANT SELECT ON nams.* TO 'Analyst_Role';


CREATE USER 'it_manager'@'localhost' IDENTIFIED BY 'AdminPass123';
DROP USER IF EXISTS 'field_officer'@'localhost';
CREATE USER 'field_officer'@'localhost' IDENTIFIED BY 'StaffPass456';

DROP USER IF EXISTS 'data_reporter'@'localhost';
CREATE USER 'data_reporter'@'localhost' IDENTIFIED BY 'ReadPass789';

GRANT 'Admin_Role' TO 'it_manager'@'localhost';
GRANT 'Staff_Role' TO 'field_officer'@'localhost';
GRANT 'Analyst_Role' TO 'data_reporter'@'localhost';

SET DEFAULT ROLE ALL TO 'it_manager'@'localhost', 'field_officer'@'localhost', 'data_reporter'@'localhost';


REVOKE DELETE ON nams.SALES FROM 'Staff_Role';

FLUSH PRIVILEGES; --[cite: 107]